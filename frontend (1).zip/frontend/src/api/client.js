const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'

let cachedToken = null

/**
 * DEV ONLY: obtains a token from the throwaway /token endpoint
 * (backend/app/api/auth_dev.py). Once this widget is embedded in the real
 * dashboard, replace this with the token the dashboard already has —
 * getCurrentToken() below is the single place that needs to change.
 */
async function getDevToken() {
  if (cachedToken) return cachedToken
  const res = await fetch(`${API_URL}/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Dashboard User' }),
  })
  if (!res.ok) {
    const bodyText = await res.text().catch(() => '')
    console.error(`Failed to obtain dev token: ${res.status} ${res.statusText}`, bodyText)
    throw new Error(`Failed to obtain dev token: ${res.status}`)
  }
  const data = await res.json()
  cachedToken = data.access_token
  return cachedToken
}

async function getCurrentToken() {
  // TODO: swap for the dashboard's real auth token once integrated.
  return getDevToken()
}

export async function sendChatMessage(message, sessionId) {
  const token = await getCurrentToken()
  const res = await fetch(`${API_URL}/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ message, session_id: sessionId }),
  })
  if (!res.ok) {
    const bodyText = await res.text().catch(() => '')
    console.error(`Chat request failed: ${res.status} ${res.statusText}`, bodyText)
    throw new Error(`Chat request failed: ${res.status}`)
  }
  return res.json()
}
